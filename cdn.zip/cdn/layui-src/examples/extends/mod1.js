
layui.define(['mod2', 'layer'], function(exports){
  var $ = layui.jquery;
  
  console.log(layui.mod2, layui.layer, layui.form)
  
  exports('mod1', {
    name: 'mod1'
  })
});